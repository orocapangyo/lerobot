## 파일 설명
setup_conda.yaml: conda 가상환경 자동 생성
requirements_conda.txt: conda 가상환경 내 종속성 생성 파일

setup_runpod.sh: runpod 자동 셋업 bash 파일
requirements_runpod.txt: runpod 내 종속성 생성 파일