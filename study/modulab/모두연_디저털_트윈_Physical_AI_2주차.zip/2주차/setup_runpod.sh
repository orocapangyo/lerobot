#!/bin/bash

echo "=========================================="
echo "🤖 LeRobot 강의 실습 환경 자동 구축 시작"
echo "=========================================="

# 1. 시스템 패키지 설치
echo ">>> [1/6] 시스템 패키지 설치 중..."
apt-get update -y
apt-get install -y ffmpeg unzip git-lfs nano

# 2. 꼬인 패키지 정리
echo ">>> [2/6] 충돌 가능성 있는 패키지 정리 중..."
pip uninstall -y blinker ipykernel jupyter_client pyzmq notebook
pip cache purge

# 3. PyTorch 업데이트 (RunPod GPU 호환성 유지)
echo ">>> [3/6] PyTorch 강제 업데이트 (CUDA 11.8)..."
pip install --upgrade torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118

# 4. 라이브러리 일괄 설치 (requirements.txt 사용)
echo ">>> [4/6] 라이브러리 목록 파일 설치..."
if [ -f "requirements_runpod.txt" ]; then
    # blinker 에러 무시 옵션을 여기에 적용
    pip install -r requirements_runpod.txt --ignore-installed blinker
else
    echo "🚨 오류: requirements_runpod.txt 파일이 없습니다!"
    exit 1
fi

# 5. 깃허브 코드 및 데이터 준비
echo ">>> [5/6] 실습 코드 및 데이터 다운로드..."
if [ -d "lerobot-mujoco-tutorial" ]; then
    rm -rf lerobot-mujoco-tutorial
fi
git clone https://github.com/jeongeun980906/lerobot-mujoco-tutorial.git

# 데이터셋 압축 풀기
if [ -f "data.zip" ]; then
    echo "   -> 학습 데이터(data.zip) 압축 해제..."
    unzip -o data.zip -d lerobot-mujoco-tutorial
fi

# 3D 에셋 압축 풀기
ASSET_DIR="lerobot-mujoco-tutorial/asset/objaverse"
if [ -f "$ASSET_DIR/data.zip" ]; then
    echo "   -> 3D 에셋 압축 해제..."
    unzip -o "$ASSET_DIR/data.zip" -d "$ASSET_DIR"
fi

# 6. Jupyter 커널 재등록
echo ">>> [6/6] Jupyter 커널 등록..."
python -m ipykernel install --user --name=python3

echo "=========================================="
echo "✅ 모든 설치가 완료되었습니다!"
echo "⚠️ [중요] 브라우저 창을 닫고, RunPod 대시보드에서 'Restart Pod'를 눌러주세요!"
echo "=========================================="